﻿namespace TestSumApplication.Models
{
    public class SumResultViewModel : ResultViewModel
    {
        public int Sum { get; set; }
    }
}
